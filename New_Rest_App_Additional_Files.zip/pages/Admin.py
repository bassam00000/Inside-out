import streamlit as st

def app():
    st.title('Admin Dashboard')
    st.write('Manage settings and view reports.')