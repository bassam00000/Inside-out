import streamlit as st

def app():
    st.title('Welcome to New Rest App')
    st.write('This is the home page.')