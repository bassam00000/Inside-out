import streamlit as st

def app():
    st.title('Menu')
    st.write('View our delicious offerings!')