import streamlit as st

def app():
    st.title('Social Space')
    st.write('Connect with others in the restaurant.')