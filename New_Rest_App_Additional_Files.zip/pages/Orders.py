import streamlit as st

def app():
    st.title('Orders')
    st.write('Track and manage customer orders.')