# New Rest App

This is a Streamlit-based restaurant app with social interaction features.

## Pages

- Home
- Menu
- Orders
- Social
- Admin

## How to Run

```bash
pip install -r requirements.txt
streamlit run app.py
```
